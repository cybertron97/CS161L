<h1><b>CS161 L</b>
<p>Lab 3</p></h1>
<h3>Tanish Arora</h3>
<p><b>Files</b> :control_unit.v, alu_control.v </p>
       <p> Lab03_tb.v (testbench)
</p>
<p><b>Team members</b> :  None </p>
<p>Test bench not tested yet, Still waiting on to demo due to a non operational Virtual Box
</p>
