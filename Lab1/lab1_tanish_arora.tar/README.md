<h1><b>CS161 L</b>
<p>Lab 1</p></h1> 
<h3>Tanish Arora</h3>
<p><b>Files</b> : my_alu.v </p>
       <p> my_alu_tb.v (testbench) 
</p>
<p><b>Team members</b> :  None </p>
<p>Test bench not tested yet, Still waiting on to demo due to a non operational Virtual Box 
</p>

<p>Links used for revision of verilog and signed bits: 
</p>
<p><b>Citation</b>: https://www.hdlworks.com/hdl_corner/verilog_ref/items/SignedArithmetic.htm
          https://stackoverflow.com/questions/24162329/verilog-signed-vs-unsigned-samples-and-first
